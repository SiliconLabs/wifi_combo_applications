Execution Steps:
--> Download the latest SAPIS release & Unzip it
--> Download the provisioning example & Unzip it
--> Copy & Paste the provisioning example (unzip folder) to the wlan examples folder in the SAPIS release, follow the below path: 
RS9116W.2.X.0.XX\examples\snippets\wlan 
--> Now open the project based on your MCU selection:
STM32F411RE         : RS9116W.2.X.0.XX\examples\snippets\wlan\provisioning\projects and double click on "provisioning-nucleo-f411re.uvprojx"
EFR32 BRD4180B MG21 : Import the project from SS5 and choose the "provisioning-brd4180b-mg21.slsproj"
EFR32 BRD4180A MG21 : Import the project from SS5 and choose the "provisioning-brd4180a-mg21.slsproj"
EFM32 BRD2204A GG11 : Import the project from SS5 and choose the "provisioning-brd2204a-gg11.slsproj"
